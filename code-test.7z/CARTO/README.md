# CARTO
Files needed for CARTO's code tryout


Dear Viewers,

Welcome to this website. This websit has been built as a test to join the team at CARTO. 

The site consist of a main page (index.html) and a second page (getting-started).

On the main page we have four tabs that change the content display onthe screen. On this proyect we were asked to complete the content on the tap "Documentation" by mimicking a given template. The remaining tabs were filled with content from www.carto.com but we chose the style to display it.

On the second page, there is a side menu with different tabs. Again, on this proyect we were asked to mimic a given template for the tab "Getting Started". As we didn't want to leave all the tabs "for ever alone", we used the web www.carto.com and its content to fill the tabs with usefull tutorials and guides.

All the pictures and content are property of https://carto.com.

Please visit https://carto.com for real tutorials and information about their products.

Thanks again for visiting this website.